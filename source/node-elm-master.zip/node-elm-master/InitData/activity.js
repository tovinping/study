export default [
{
description: "",
icon_color: "3FBDE6",
icon_name: "品",
id: 8,
name: "品牌商家",
ranking_weight: 7
},
{
description: "已加入“外卖保”计划，食品安全有保障",
icon_color: "999999",
icon_name: "保",
id: 7,
name: "外卖保",
ranking_weight: 6
},
{
description: "新店",
icon_color: "E8842D",
icon_name: "新",
id: 5,
name: "新店",
ranking_weight: 4
},
{
description: "该商家支持开发票，请在下单时填写好发票抬头",
icon_color: "999999",
icon_name: "票",
id: 4,
name: "开发票",
ranking_weight: 3
},
{
description: "可使用支付宝、微信、手机QQ进行在线支付",
icon_color: "FF4E00",
icon_name: "付",
id: 3,
name: "在线支付",
ranking_weight: 2
},
{
description: "准时必达，超时秒赔",
icon_color: "57A9FF",
icon_name: "准",
id: 9,
name: "准时达",
ranking_weight: 1
}
]